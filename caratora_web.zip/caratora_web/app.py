from flask import Flask, render_template, request, redirect, url_for, flash
import csv
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'caratora-secret-2025'

CSV_FILE = 'pendaftar.csv'

def init_csv():
    """Buat file CSV dengan header jika belum ada."""
    if not os.path.exists(CSV_FILE):
        with open(CSV_FILE, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow([
                'Tanggal', 'Nama Institusi', 'Nama PIC',
                'Email', 'WhatsApp', 'Jenis Kemitraan', 'Pesan'
            ])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/kirim-daftar', methods=['POST'])
def kirim_daftar():
    nama_institusi  = request.form.get('nama_institusi', '').strip()
    nama_pic        = request.form.get('nama_pic', '').strip()
    email           = request.form.get('email', '').strip()
    whatsapp        = request.form.get('whatsapp', '').strip()
    jenis           = request.form.get('jenis_kemitraan', '').strip()
    pesan           = request.form.get('pesan', '').strip()

    # Validasi dasar
    if not all([nama_institusi, nama_pic, email, whatsapp, jenis]):
        flash('Harap lengkapi semua kolom yang wajib diisi (*).', 'error')
        return redirect(url_for('index') + '#daftar')

    # Simpan ke CSV
    init_csv()
    with open(CSV_FILE, 'a', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow([
            datetime.now().strftime('%Y-%m-%d %H:%M'),
            nama_institusi, nama_pic, email, whatsapp, jenis, pesan
        ])

    flash(f'Terima kasih, {nama_pic}! Permohonan kemitraan dari {nama_institusi} sudah kami terima. Tim kami akan menghubungi Anda dalam 2×24 jam.', 'success')
    return redirect(url_for('index') + '#daftar')

@app.route('/admin/pendaftar')
def lihat_pendaftar():
    """Halaman sederhana untuk melihat daftar pendaftar."""
    rows = []
    if os.path.exists(CSV_FILE):
        with open(CSV_FILE, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            rows = list(reader)
    return render_template('admin.html', rows=rows)

if __name__ == '__main__':
    init_csv()
    app.run(debug=True, port=5000)
