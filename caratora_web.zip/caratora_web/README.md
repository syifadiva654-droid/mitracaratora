# CaraTora — Website Kemitraan Edukasi Animasi Bahasa Jawa

Platform web berbasis Python Flask untuk program kemitraan CaraTora.

---

## 📁 Struktur Proyek

```
caratora/
├── app.py                  ← Backend Flask (logika server)
├── requirements.txt        ← Daftar dependensi Python
├── pendaftar.csv           ← Data pendaftar (dibuat otomatis)
├── templates/
│   ├── index.html          ← Halaman utama
│   └── admin.html          ← Halaman admin (lihat pendaftar)
└── static/
    └── css/
        └── style.css       ← Semua styling
```

---

## 🚀 Cara Menjalankan (Langkah demi Langkah)

### 1. Pastikan Python sudah terinstal
Buka Terminal / Command Prompt, ketik:
```
python --version
```
Harus muncul versi Python 3.8 ke atas.

### 2. Buka folder proyek di Terminal
```bash
cd path/ke/folder/caratora
```
Contoh (Windows): `cd C:\Users\NamaKamu\Documents\caratora`  
Contoh (Mac/Linux): `cd ~/Documents/caratora`

### 3. Buat Virtual Environment (direkomendasikan)
```bash
python -m venv venv
```
Aktifkan:
- Windows: `venv\Scripts\activate`
- Mac/Linux: `source venv/bin/activate`

### 4. Install Flask
```bash
pip install -r requirements.txt
```

### 5. Jalankan aplikasi
```bash
python app.py
```

### 6. Buka di browser
Kunjungi: **http://localhost:5000**

---

## 🌐 Halaman yang Tersedia

| URL | Keterangan |
|-----|-----------|
| `http://localhost:5000/` | Halaman utama website |
| `http://localhost:5000/admin/pendaftar` | Lihat semua data pendaftar |

---

## 📋 Fitur

- ✅ Website landing page CaraTora (Hero, Tentang, Keunggulan, Paket, Alur)
- ✅ Formulir pendaftaran mitra yang fungsional
- ✅ Data tersimpan otomatis ke `pendaftar.csv`
- ✅ Notifikasi sukses/gagal setelah submit form
- ✅ Halaman admin untuk melihat daftar pendaftar
- ✅ Desain responsif (mobile-friendly)
- ✅ Tema Cokelat Gelap Jawa & Emas

---

## 🛠️ Kustomisasi

- **Ubah konten teks**: Edit file `templates/index.html`
- **Ubah warna/style**: Edit file `static/css/style.css`
- **Ubah logika backend**: Edit file `app.py`

---

© 2025 CaraTora — Kudus, Jawa Tengah, Indonesia
